const fs=require('fs');
const html=fs.readFileSync(__dirname+'/index.html','utf8');
const required=[
  'CREATE IMPOSSIBLE VISUALS','BREAK REALITY','EXPORT STILL','MAKE A LOOP','SHARE WORLD',
  'PRICING','FREE','CREATOR','PRO','UPGRADE','AI WORLD BUILDER','GENERATE WORLD',
  '9:16','1:1','16:9','COMMERCIAL USE','World DNA','COPY LINK','DOWNLOAD PNG'
];
for(const s of required){if(!html.toLowerCase().includes(s.toLowerCase())) throw new Error('missing '+s)}
if(!html.includes('fetch(')) throw new Error('missing AI API integration hook');
if(!html.includes('checkout')) throw new Error('missing checkout integration hook');
if(!html.includes('manifest')) throw new Error('missing PWA manifest');
console.log('commercial product contract tests: PASS');

// Product-hardening contract: commercial UX must explain limits and protect trust.
for(const s of ['TERMS','PRIVACY','AI CREDITS','CREATOR EXPORTS','PRO EXPORTS','MANAGE PLAN','CANCEL ANYTIME','NO CARD REQUIRED']){
  if(!html.toLowerCase().includes(s.toLowerCase())) throw new Error('missing '+s)
}
if(!html.includes('usage')) throw new Error('missing usage state');
if(!fs.existsSync(__dirname+'/api/stripe-webhook.js')) throw new Error('missing Stripe webhook');
if(!fs.existsSync(__dirname+'/api/usage.js')) throw new Error('missing usage endpoint');
const aiFnStart=html.indexOf('async function generateAI()');
const aiFn=html.slice(aiFnStart, html.indexOf('\n', aiFnStart+1)+1);
if(aiFn.indexOf("const prompt")>aiFn.indexOf('consumeAi')) throw new Error('AI credit consumed before prompt validation');
if(!html.includes('serviceWorker')) throw new Error('missing PWA service worker registration');
if(!fs.existsSync(__dirname+'/sw.js')) throw new Error('missing service worker');
