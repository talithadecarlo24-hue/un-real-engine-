# The Unreality Engine

**Create impossible visuals. Bend reality. Capture it. Share it.**

The Unreality Engine is a browser-based procedural visual creator with an AI world-builder, editable world DNA, creator exports, saved worlds, shareable world URLs and a premium-ready product layer.

## What is included

- Living procedural canvas world — not a static image
- Chaos, Dream, Motion, Gravity, Distortion and Colour controls
- Random worlds, presets, Break Reality and drag interaction
- AI World Builder using the OpenAI Responses API
- Free / Creator / Pro product UX
- Local AI-credit usage meter and upgrade flow
- 16:9, 9:16 and 1:1 creator workflow
- PNG and browser WebM loop export
- World save/gallery and shareable world links
- PWA manifest + service worker shell
- Stripe Checkout endpoint
- Stripe webhook signature verification endpoint
- Terms / Privacy trust UI
- Responsive mobile layout

OpenAI's current model catalog lists GPT-5.6 Luna (`gpt-5.6-luna`) as a cost-sensitive model available through the Responses API. Choose a different model through `OPENAI_MODEL` if your production budget or quality target changes.

## Commercial model

Proposed launch pricing:

| Plan | Price | Intended offer |
|---|---:|---|
| Free | €0 | Explore, basic controls, standard PNG, limited AI |
| Creator | €9/mo | AI creation, HD loops, social formats, commercial use |
| Pro | €19/mo | Higher limits, 4K workflow, advanced packs, priority generation |

These are **proposed launch prices**, not validated market pricing.

## Production setup

1. Deploy the static root and `/api` handlers on a serverless platform that supports ESM handlers.
2. Add the variables in `.env.example` to the production environment.
3. Create recurring Stripe Prices for Creator and Pro.
4. Configure a Stripe webhook for `checkout.session.completed`, `customer.subscription.updated` and `customer.subscription.deleted` and set `STRIPE_WEBHOOK_SECRET`.
5. Add authentication + a persistent database before launch so plan, usage, customer ID and subscription state are server-authoritative. The included local usage meter is deliberately only a UX/demo fallback.
6. Replace the demo `DEFAULT_PLAN` fallback with authenticated subscription lookup in `/api/usage.js`.
7. Configure the Stripe customer billing portal for authenticated subscribers.
8. Publish final Terms, Privacy Policy, refund/cancellation language and Malta/EU VAT/tax treatment with appropriate professional review.
9. Run Stripe in test mode and test AI generation, checkout, webhook events, exports and mobile behavior before switching live.

## Security notes

- Never put `OPENAI_API_KEY` or `STRIPE_SECRET_KEY` in browser code.
- AI generation and Stripe Checkout are server-side.
- The webhook rejects invalid/expired Stripe signatures.
- The local plan/usage state is **not** a security boundary; production entitlements must come from authenticated server state.

## Local smoke test

```bash
node test.js
node --check api/generate-world.js
node --check api/create-checkout.js
node --check api/stripe-webhook.js
node --check api/usage.js
node --check sw.js
```

The test suite is intentionally lightweight and dependency-free so the project can be inspected and deployed without a build system.
