import crypto from 'node:crypto';

function signatureIsValid(raw, signature, secret){
  if(!signature||!secret) return false;
  const parts=Object.fromEntries(signature.split(',').map(x=>x.split('=')));
  if(!parts.t||!parts.v1) return false;
  const age=Math.abs(Date.now()/1000-Number(parts.t));
  if(!Number.isFinite(age)||age>300) return false;
  const expected=crypto.createHmac('sha256',secret).update(`${parts.t}.${raw}`).digest('hex');
  return crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(parts.v1));
}
export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).json({error:'Method not allowed'});
  const secret=process.env.STRIPE_WEBHOOK_SECRET;
  if(!secret) return res.status(503).json({error:'STRIPE_WEBHOOK_SECRET is not configured'});
  const raw=typeof req.body==='string'?req.body:JSON.stringify(req.body||{});
  if(!signatureIsValid(raw,req.headers['stripe-signature'],secret)) return res.status(400).json({error:'Invalid Stripe signature'});
  const event=JSON.parse(raw);
  const supported=['checkout.session.completed','customer.subscription.updated','customer.subscription.deleted'];
  if(supported.includes(event.type)) console.log(JSON.stringify({type:event.type,id:event.id}));
  return res.status(200).json({received:true});
}
