const plans={free:{ai:3,export:'standard'},creator:{ai:100,export:'hd'},pro:{ai:300,export:'4k'}};
export default async function handler(req,res){
  if(req.method!=='GET') return res.status(405).json({error:'Method not allowed'});
  const plan=plans[process.env.DEFAULT_PLAN||'free']?process.env.DEFAULT_PLAN||'free':'free';
  return res.status(200).json({plan,limits:plans[plan],productionNote:'Replace DEFAULT_PLAN with authenticated subscription lookup before launch.'});
}
