export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).json({error:'Method not allowed'});
  if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:'OPENAI_API_KEY is not configured'});
  try{
    const {prompt=''}=req.body||{};
    const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${process.env.OPENAI_API_KEY}`},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-5.6-luna',input:[{role:'system',content:[{type:'input_text',text:'You design parameter recipes for The Unreality Engine. Return JSON only with keys chaos,dream,motion,gravity,distortion,colour,note. Numbers: 0-100 except colour 0-359. Make the recipe evocative but coherent.'}]},{role:'user',content:[{type:'input_text',text:String(prompt).slice(0,1200)}]}],text:{format:{type:'json_schema',name:'unreality_world',schema:{type:'object',properties:{chaos:{type:'number'},dream:{type:'number'},motion:{type:'number'},gravity:{type:'number'},distortion:{type:'number'},colour:{type:'number'},note:{type:'string'}},required:['chaos','dream','motion','gravity','distortion','colour','note'],additionalProperties:false},strict:true}}})});
    if(!r.ok) return res.status(r.status).json({error:'AI provider error'});
    const data=await r.json();const text=data.output_text||data.output?.flatMap(x=>x.content||[]).find(x=>x.text)?.text;
    return res.status(200).json({world:JSON.parse(text)});
  }catch(e){return res.status(500).json({error:'Generation failed'});}
}
