export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).json({error:'Method not allowed'});
  if(!process.env.STRIPE_SECRET_KEY) return res.status(503).json({error:'STRIPE_SECRET_KEY is not configured'});
  const plan=req.body?.plan;
  const priceId=plan==='pro'?process.env.STRIPE_PRO_PRICE_ID:plan==='creator'?process.env.STRIPE_CREATOR_PRICE_ID:null;
  if(!priceId) return res.status(400).json({error:'Missing Stripe price ID'});
  try{
    const params=new URLSearchParams({mode:'subscription','line_items[0][price]':priceId,'line_items[0][quantity]':'1','success_url':`${process.env.APP_URL||'http://localhost:3000'}?checkout=success`,'cancel_url':`${process.env.APP_URL||'http://localhost:3000'}?checkout=cancelled`});
    const r=await fetch('https://api.stripe.com/v1/checkout/sessions',{method:'POST',headers:{Authorization:`Bearer ${process.env.STRIPE_SECRET_KEY}`,'Content-Type':'application/x-www-form-urlencoded'},body:params});
    const data=await r.json();if(!r.ok) return res.status(r.status).json({error:'Stripe error'});return res.status(200).json({url:data.url});
  }catch(e){return res.status(500).json({error:'Checkout failed'});}
}
